﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmVentas : Form
    {
        decimal totalVenta = 0;

        public FrmVentas()
        {
            InitializeComponent();
        }

        private void FrmVentas_Load(object sender, EventArgs e)
        {
            CargarClientes();
            CargarEmpleados();
            CargarServicios();

            txtPrecio.ReadOnly = true;
            txtTotal.ReadOnly = true;
        }

        public void CargarClientes()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT IdCliente, Nombre FROM Clientes", cn);

                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbCliente.DataSource = dt;
                cmbCliente.DisplayMember = "Nombre";
                cmbCliente.ValueMember = "IdCliente";
            }
        }

        public void CargarEmpleados()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT IdEmpleado, Nombre FROM Empleados", cn);

                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbEmpleado.DataSource = dt;
                cmbEmpleado.DisplayMember = "Nombre";
                cmbEmpleado.ValueMember = "IdEmpleado";
            }
        }

        public void CargarServicios()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT IdServicio, NombreServicio, Precio FROM Servicios", cn);

                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbServicio.DataSource = dt;
                cmbServicio.DisplayMember = "NombreServicio";
                cmbServicio.ValueMember = "IdServicio";
            }
        }

        private void cmbServicio_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbServicio.SelectedValue != null)
            {
                DataRowView fila = cmbServicio.SelectedItem as DataRowView;

                if (fila != null)
                {
                    txtPrecio.Text = fila["Precio"].ToString();
                }
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string servicio = cmbServicio.Text;

            decimal precio = Convert.ToDecimal(txtPrecio.Text);

            dgvDetalleVenta.Rows.Add(servicio, precio);

            totalVenta += precio;

            txtTotal.Text = totalVenta.ToString();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            dgvDetalleVenta.Rows.Clear();

            txtPrecio.Clear();
            txtTotal.Clear();

            totalVenta = 0;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (dgvDetalleVenta.Rows.Count == 0)
            {
                MessageBox.Show("Debe agregar al menos un servicio");
                return;
            }

            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consultaVenta = "INSERT INTO Ventas (IdCliente, IdEmpleado, Total) OUTPUT INSERTED.IdVenta VALUES (@IdCliente, @IdEmpleado, @Total)";

                SqlCommand cmdVenta = new SqlCommand(consultaVenta, cn);
                cmdVenta.Parameters.AddWithValue("@IdCliente", cmbCliente.SelectedValue);
                cmdVenta.Parameters.AddWithValue("@IdEmpleado", cmbEmpleado.SelectedValue);
                cmdVenta.Parameters.AddWithValue("@Total", totalVenta);

                int idVenta = Convert.ToInt32(cmdVenta.ExecuteScalar());

                foreach (DataGridViewRow fila in dgvDetalleVenta.Rows)
                {
                    if (fila.Cells["Servicio"].Value != null)
                    {
                        string nombreServicio = fila.Cells["Servicio"].Value.ToString();
                        decimal precio = Convert.ToDecimal(fila.Cells["Precio"].Value);

                        string buscarServicio = "SELECT IdServicio FROM Servicios WHERE NombreServicio=@NombreServicio";

                        SqlCommand cmdBuscar = new SqlCommand(buscarServicio, cn);
                        cmdBuscar.Parameters.AddWithValue("@NombreServicio", nombreServicio);

                        int idServicio = Convert.ToInt32(cmdBuscar.ExecuteScalar());

                        string consultaDetalle = "INSERT INTO DetalleVentas (IdVenta, IdServicio, Precio) VALUES (@IdVenta, @IdServicio, @Precio)";

                        SqlCommand cmdDetalle = new SqlCommand(consultaDetalle, cn);
                        cmdDetalle.Parameters.AddWithValue("@IdVenta", idVenta);
                        cmdDetalle.Parameters.AddWithValue("@IdServicio", idServicio);
                        cmdDetalle.Parameters.AddWithValue("@Precio", precio);

                        cmdDetalle.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Venta guardada correctamente");

                dgvDetalleVenta.Rows.Clear();
                txtPrecio.Clear();
                txtTotal.Clear();
                totalVenta = 0;
            }
        }
    }
}
