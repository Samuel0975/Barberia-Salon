﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmInventario : Form
    {
        int idProducto = 0;

        public FrmInventario()
        {
            InitializeComponent();
        }

        private void FrmInventario_Load(object sender, EventArgs e)
        {
            MostrarProductos();
        }

        public void MostrarProductos()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "SELECT * FROM Productos";
                SqlDataAdapter da = new SqlDataAdapter(consulta, cn);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dgvProductos.DataSource = dt;
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        public void LimpiarCampos()
        {
            txtNombreProducto.Clear();
            cmbCategoria.SelectedIndex = -1;
            txtCantidad.Clear();
            txtPrecioCompra.Clear();
            idProducto = 0;
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idProducto = Convert.ToInt32(dgvProductos.Rows[e.RowIndex].Cells["IdProducto"].Value);

                txtNombreProducto.Text = dgvProductos.Rows[e.RowIndex].Cells["NombreProducto"].Value.ToString();
                cmbCategoria.Text = dgvProductos.Rows[e.RowIndex].Cells["Categoria"].Value.ToString();
                txtCantidad.Text = dgvProductos.Rows[e.RowIndex].Cells["Cantidad"].Value.ToString();
                txtPrecioCompra.Text = dgvProductos.Rows[e.RowIndex].Cells["PrecioCompra"].Value.ToString();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idProducto == 0)
            {
                MessageBox.Show("Seleccione un producto primero");
                return;
            }

            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "DELETE FROM Productos WHERE IdProducto=@IdProducto";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@IdProducto", idProducto);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Producto eliminado correctamente");

                MostrarProductos();
                LimpiarCampos();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "INSERT INTO Productos (NombreProducto, Categoria, Cantidad, PrecioCompra) VALUES (@NombreProducto, @Categoria, @Cantidad, @PrecioCompra)";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@NombreProducto", txtNombreProducto.Text);
                cmd.Parameters.AddWithValue("@Categoria", cmbCategoria.Text);
                cmd.Parameters.AddWithValue("@Cantidad", txtCantidad.Text);
                cmd.Parameters.AddWithValue("@PrecioCompra", txtPrecioCompra.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Producto guardado correctamente");

                MostrarProductos();
                LimpiarCampos();
            }
        }

        private void dgvProductos_CellClick(object sender, EventArgs e)
        {

        }
    }
}