﻿using System.Data.SqlClient;

namespace BeautyBarber_Grup1.Datos
{
    public class Conexion
    {
        private string cadena =
        "Server=(localdb)\\MSSQLLocalDB;Database=BeautyBarberGrup1;Trusted_Connection=True;";

        public SqlConnection Conectar()
        {
            return new SqlConnection(cadena);
        }
    }
}