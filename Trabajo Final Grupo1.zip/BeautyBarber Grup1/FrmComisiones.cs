﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmComisiones : Form
    {
        public FrmComisiones()
        {
            InitializeComponent();
        }

        private void FrmComisiones_Load(object sender, EventArgs e)
        {
            CargarEmpleados();
            MostrarComisiones();

            txtTotalVentas.ReadOnly = true;
            txtPorcentaje.ReadOnly = true;
            txtTotalComision.ReadOnly = true;
        }

        public void CargarEmpleados()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT IdEmpleado, Nombre, PorcentajeComision FROM Empleados", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbEmpleado.DataSource = dt;
                cmbEmpleado.DisplayMember = "Nombre";
                cmbEmpleado.ValueMember = "IdEmpleado";
            }
        }

        private void cmbEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView fila = cmbEmpleado.SelectedItem as DataRowView;

            if (fila != null)
            {
                txtPorcentaje.Text = fila["PorcentajeComision"].ToString();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = @"SELECT ISNULL(SUM(Total), 0) 
                                    FROM Ventas 
                                    WHERE IdEmpleado = @IdEmpleado
                                    AND CAST(FechaVenta AS DATE) BETWEEN @FechaInicio AND @FechaFin";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@IdEmpleado", cmbEmpleado.SelectedValue);
                cmd.Parameters.AddWithValue("@FechaInicio", dtpFechaInicio.Value.Date);
                cmd.Parameters.AddWithValue("@FechaFin", dtpFechaFin.Value.Date);

                decimal totalVentas = Convert.ToDecimal(cmd.ExecuteScalar());
                decimal porcentaje = Convert.ToDecimal(txtPorcentaje.Text);
                decimal totalComision = totalVentas * (porcentaje / 100);

                txtTotalVentas.Text = totalVentas.ToString();
                txtTotalComision.Text = totalComision.ToString();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = @"INSERT INTO Comisiones 
                (IdEmpleado, FechaInicio, FechaFin, TotalVentas, Porcentaje, TotalComision)
                VALUES (@IdEmpleado, @FechaInicio, @FechaFin, @TotalVentas, @Porcentaje, @TotalComision)";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@IdEmpleado", cmbEmpleado.SelectedValue);
                cmd.Parameters.AddWithValue("@FechaInicio", dtpFechaInicio.Value.Date);
                cmd.Parameters.AddWithValue("@FechaFin", dtpFechaFin.Value.Date);
                cmd.Parameters.AddWithValue("@TotalVentas", txtTotalVentas.Text);
                cmd.Parameters.AddWithValue("@Porcentaje", txtPorcentaje.Text);
                cmd.Parameters.AddWithValue("@TotalComision", txtTotalComision.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Comisión guardada correctamente");

                MostrarComisiones();
                LimpiarCampos();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        public void LimpiarCampos()
        {
            txtTotalVentas.Clear();
            txtTotalComision.Clear();
        }

        public void MostrarComisiones()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = @"SELECT C.IdComision, E.Nombre AS Empleado, 
                                    C.FechaInicio, C.FechaFin, 
                                    C.TotalVentas, C.Porcentaje, C.TotalComision
                                    FROM Comisiones C
                                    INNER JOIN Empleados E ON C.IdEmpleado = E.IdEmpleado";

                SqlDataAdapter da = new SqlDataAdapter(consulta, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvComisiones.DataSource = dt;
            }
        }
    }
}