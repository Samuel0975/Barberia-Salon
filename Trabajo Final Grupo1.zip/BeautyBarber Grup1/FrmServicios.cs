﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmServicios : Form
    {
        int idServicio = 0;

        public FrmServicios()
        {
            InitializeComponent();
        }

        private void FrmServicios_Load(object sender, EventArgs e)
        {
            MostrarServicios();
        }

        public void MostrarServicios()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "SELECT * FROM Servicios";

                SqlDataAdapter da = new SqlDataAdapter(consulta, cn);

                DataTable dt = new DataTable();

                da.Fill(dt);

                dgvServicios.DataSource = dt;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "INSERT INTO Servicios (NombreServicio, Categoria, Precio) VALUES (@NombreServicio, @Categoria, @Precio)";

                SqlCommand cmd = new SqlCommand(consulta, cn);

                cmd.Parameters.AddWithValue("@NombreServicio", txtNombreServicio.Text);
                cmd.Parameters.AddWithValue("@Categoria", cmbCategoria.Text);
                cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Servicio guardado correctamente");

                MostrarServicios();

                LimpiarCampos();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        public void LimpiarCampos()
        {
            txtNombreServicio.Clear();
            txtPrecio.Clear();
            cmbCategoria.SelectedIndex = -1;

            idServicio = 0;
        }

        private void dgvServicios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idServicio = Convert.ToInt32(dgvServicios.Rows[e.RowIndex].Cells["IdServicio"].Value);

                txtNombreServicio.Text = dgvServicios.Rows[e.RowIndex].Cells["NombreServicio"].Value.ToString();

                cmbCategoria.Text = dgvServicios.Rows[e.RowIndex].Cells["Categoria"].Value.ToString();

                txtPrecio.Text = dgvServicios.Rows[e.RowIndex].Cells["Precio"].Value.ToString();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idServicio == 0)
            {
                MessageBox.Show("Seleccione un servicio");
                return;
            }

            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "DELETE FROM Servicios WHERE IdServicio=@IdServicio";

                SqlCommand cmd = new SqlCommand(consulta, cn);

                cmd.Parameters.AddWithValue("@IdServicio", idServicio);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Servicio eliminado correctamente");

                MostrarServicios();

                LimpiarCampos();
            }
        }
    }
}