﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmReportes : Form
    {
        public FrmReportes()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consultaVentas = @"SELECT IdVenta, IdCliente, IdEmpleado, FechaVenta, Total
                                         FROM Ventas
                                         WHERE CAST(FechaVenta AS DATE) BETWEEN @Inicio AND @Fin";

                SqlDataAdapter da = new SqlDataAdapter(consultaVentas, cn);
                da.SelectCommand.Parameters.AddWithValue("@Inicio", dtpInicio.Value.Date);
                da.SelectCommand.Parameters.AddWithValue("@Fin", dtpFin.Value.Date);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvReportes.DataSource = dt;

                string totalVentas = @"SELECT ISNULL(SUM(Total),0)
                                       FROM Ventas
                                       WHERE CAST(FechaVenta AS DATE) BETWEEN @Inicio AND @Fin";

                SqlCommand cmdVentas = new SqlCommand(totalVentas, cn);
                cmdVentas.Parameters.AddWithValue("@Inicio", dtpInicio.Value.Date);
                cmdVentas.Parameters.AddWithValue("@Fin", dtpFin.Value.Date);

                txtTotalVentas.Text = cmdVentas.ExecuteScalar().ToString();

                string totalComisiones = @"SELECT ISNULL(SUM(TotalComision),0)
                                           FROM Comisiones
                                           WHERE FechaInicio >= @Inicio AND FechaFin <= @Fin";

                SqlCommand cmdComisiones = new SqlCommand(totalComisiones, cn);
                cmdComisiones.Parameters.AddWithValue("@Inicio", dtpInicio.Value.Date);
                cmdComisiones.Parameters.AddWithValue("@Fin", dtpFin.Value.Date);

                txtTotalComisiones.Text = cmdComisiones.ExecuteScalar().ToString();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtTotalVentas.Clear();
            txtTotalComisiones.Clear();
            dgvReportes.DataSource = null;
        }
    }
}