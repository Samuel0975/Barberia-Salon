﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using BeautyBarber_Grup1.Datos;

namespace BeautyBarber_Grup1
{
    public partial class FrmClientes : Form
    {
        int idCliente = 0;

        public FrmClientes()
        {
            InitializeComponent();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {
            MostrarClientes();
        }

        public void MostrarClientes()
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "SELECT * FROM Clientes";
                SqlDataAdapter da = new SqlDataAdapter(consulta, cn);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dgvClientes.DataSource = dt;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "INSERT INTO Clientes (Nombre, Telefono, Direccion, TipoCliente, Observacion) VALUES (@Nombre, @Telefono, @Direccion, @TipoCliente, @Observacion)";

                SqlCommand cmd = new SqlCommand(consulta, cn);

                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
                cmd.Parameters.AddWithValue("@Direccion", txtDireccion.Text);
                cmd.Parameters.AddWithValue("@TipoCliente", txtTipoCliente.Text);
                cmd.Parameters.AddWithValue("@Observacion", txtObservacion.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Cliente guardado correctamente");

                MostrarClientes();
                LimpiarCampos();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtDireccion.Clear();
            txtTipoCliente.Clear();
            txtObservacion.Clear();
            idCliente = 0;
        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idCliente = Convert.ToInt32(dgvClientes.Rows[e.RowIndex].Cells["IdCliente"].Value);

                txtNombre.Text = dgvClientes.Rows[e.RowIndex].Cells["Nombre"].Value.ToString();
                txtTelefono.Text = dgvClientes.Rows[e.RowIndex].Cells["Telefono"].Value.ToString();
                txtDireccion.Text = dgvClientes.Rows[e.RowIndex].Cells["Direccion"].Value.ToString();
                txtTipoCliente.Text = dgvClientes.Rows[e.RowIndex].Cells["TipoCliente"].Value.ToString();
                txtObservacion.Text = dgvClientes.Rows[e.RowIndex].Cells["Observacion"].Value.ToString();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idCliente == 0)
            {
                MessageBox.Show("Seleccione un cliente primero");
                return;
            }

            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "DELETE FROM Clientes WHERE IdCliente=@IdCliente";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@IdCliente", idCliente);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Cliente eliminado correctamente");

                MostrarClientes();
                LimpiarCampos();
            }
        

        }

        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            if (idCliente == 0)
            {
                MessageBox.Show("Seleccione un cliente primero");
                return;
            }

            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.Conectar())
            {
                cn.Open();

                string consulta = "DELETE FROM Clientes WHERE IdCliente=@IdCliente";

                SqlCommand cmd = new SqlCommand(consulta, cn);
                cmd.Parameters.AddWithValue("@IdCliente", idCliente);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Cliente eliminado correctamente");

                MostrarClientes();
                LimpiarCampos();
            }
        }
    }
}